package com.wifiradarpro

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.cos
import kotlin.math.sin

private val Bg = Color(0xFF06111F)
private val Panel = Color(0xFF0D1D30)
private val Cyan = Color(0xFF22D3EE)
private val Green = Color(0xFF35F2A0)
private val Muted = Color(0xFF91A7BC)
private val White = Color(0xFFEAF7FF)

data class WifiNetwork(
    val ssid: String,
    val bssid: String,
    val rssi: Int,
    val frequency: Int,
    val security: String
) {
    val signalPercent: Int get() = (((rssi + 100).coerceIn(0, 70) / 70f) * 100).toInt()
    val proximity: String get() = when {
        signalPercent >= 75 -> "Muito próxima"
        signalPercent >= 50 -> "Próxima"
        signalPercent >= 25 -> "Distância média"
        else -> "Sinal distante"
    }
    val isOpen: Boolean get() = security == "Aberta"
}

class MainActivity : ComponentActivity() {
    private lateinit var wifiManager: WifiManager
    private var scanReceiver: BroadcastReceiver? = null
    private var onScanUpdate: ((List<WifiNetwork>, String) -> Unit)? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startWifiScan() else onScanUpdate?.invoke(emptyList(),
                "Permissão de localização negada. Ela é exigida pelo Android para mostrar resultados do Wi-Fi.")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

        setContent {
            var networks by remember { mutableStateOf(emptyList<WifiNetwork>()) }
            var status by remember { mutableStateOf("Pronto para procurar redes próximas") }
            var scanning by remember { mutableStateOf(false) }
            var history by remember { mutableStateOf(loadHistory()) }

            onScanUpdate = { list, message ->
                networks = list
                status = message
                scanning = false
                if (list.isNotEmpty()) {
                    history = saveHistory(list)
                }
            }

            LaunchedEffect(Unit) {
                // Keep the UI responsive if Android throttles or delays scan broadcasts.
                while (true) {
                    delay(1000)
                    if (scanning && status == "Procurando redes próximas…") {
                        status = "Escaneando. O Android pode limitar a frequência das buscas."
                    }
                }
            }

            WifiRadarTheme {
                MainScreen(
                    networks = networks,
                    status = status,
                    scanning = scanning,
                    historyCount = history.size,
                    onScan = {
                        if (ContextCompat.checkSelfPermission(
                                this, Manifest.permission.ACCESS_FINE_LOCATION
                            ) != PackageManager.PERMISSION_GRANTED
                        ) {
                            permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                        } else {
                            scanning = true
                            status = "Procurando redes próximas…"
                            startWifiScan()
                        }
                    },
                    onSettings = {
                        startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                    },
                    onHistory = { status = if (history.isEmpty()) "Nenhuma verificação salva ainda."
                        else "Histórico: ${history.size} verificação(ões) salva(s) neste aparelho." }
                )
            }
        }
    }

    private fun startWifiScan() {
        if (!wifiManager.isWifiEnabled) {
            onScanUpdate?.invoke(emptyList(), "Wi-Fi desligado. Ative o Wi-Fi e tente novamente.")
            return
        }

        try {
            scanReceiver?.let { runCatching { unregisterReceiver(it) } }
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    val updated = intent?.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, false) ?: false
                    val results = runCatching { wifiManager.scanResults }.getOrDefault(emptyList())
                    val mapped = results.mapNotNull { it.toWifiNetwork() }
                        .distinctBy { it.bssid }
                        .sortedByDescending { it.rssi }
                    onScanUpdate?.invoke(
                        mapped,
                        if (mapped.isEmpty()) {
                            if (updated) "Nenhuma rede encontrada. Tente novamente em outro local."
                            else "O Android não atualizou a varredura. Tente novamente mais tarde."
                        } else "${mapped.size} rede(s) encontrada(s)."
                    )
                    runCatching { unregisterReceiver(this) }
                    scanReceiver = null
                }
            }
            scanReceiver = receiver
            val filter = IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(receiver, filter)
            }
            @Suppress("DEPRECATION")
            val started = wifiManager.startScan()
            if (!started) {
                // Existing scan results can still be returned when Android throttles new scans.
                val cached = runCatching { wifiManager.scanResults }.getOrDefault(emptyList())
                val mapped = cached.mapNotNull { it.toWifiNetwork() }
                    .distinctBy { it.bssid }.sortedByDescending { it.rssi }
                onScanUpdate?.invoke(mapped,
                    if (mapped.isNotEmpty()) "Resultados disponíveis (varredura nova limitada pelo Android)."
                    else "O Android limitou a nova varredura. Aguarde e tente novamente.")
                runCatching { unregisterReceiver(receiver) }
                scanReceiver = null
            }
        } catch (_: SecurityException) {
            onScanUpdate?.invoke(emptyList(), "Permissão insuficiente. Verifique as permissões do aplicativo.")
        } catch (e: Exception) {
            onScanUpdate?.invoke(emptyList(), "Não foi possível escanear: ${e.localizedMessage ?: "erro desconhecido"}")
        }
    }

    @Suppress("DEPRECATION")
    private fun ScanResult.toWifiNetwork(): WifiNetwork? {
        val name = SSID.trim().ifBlank { "(SSID oculto)" }
        val caps = capabilities.uppercase()
        val security = when {
            caps.contains("SAE") -> "WPA3"
            caps.contains("WPA2") -> "WPA2"
            caps.contains("WPA") -> "WPA/WPA2"
            caps.contains("WEP") -> "WEP"
            caps.contains("EAP") -> "WPA-Enterprise"
            else -> "Aberta"
        }
        return WifiNetwork(name, BSSID ?: name, level, frequency, security)
    }

    private fun loadHistory(): List<String> {
        val raw = getSharedPreferences("radar", MODE_PRIVATE).getString("history", "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        }.getOrDefault(emptyList())
    }

    private fun saveHistory(list: List<WifiNetwork>): List<String> {
        val old = loadHistory()
        val entry = "${System.currentTimeMillis()} • ${list.size} redes"
        val next = (listOf(entry) + old).take(10)
        val arr = JSONArray()
        next.forEach { arr.put(it) }
        getSharedPreferences("radar", MODE_PRIVATE).edit().putString("history", arr.toString()).apply()
        return next
    }

    override fun onDestroy() {
        scanReceiver?.let { runCatching { unregisterReceiver(it) } }
        super.onDestroy()
    }
}

@Composable
private fun WifiRadarTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, secondary = Green, background = Bg, surface = Panel,
            onPrimary = Bg, onBackground = White, onSurface = White
        ),
        content = content
    )
}

@Composable
private fun MainScreen(
    networks: List<WifiNetwork>,
    status: String,
    scanning: Boolean,
    historyCount: Int,
    onScan: () -> Unit,
    onSettings: () -> Unit,
    onHistory: () -> Unit
) {
    val transition = rememberInfiniteTransition(label = "radar")
    val sweep by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(if (scanning) 2200 else 6500), RepeatMode.Restart),
        label = "sweep"
    )
    val pulse by transition.animateFloat(
        initialValue = 0.82f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
        label = "pulse"
    )

    Column(
        modifier = Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF07182A), Bg, Color(0xFF030A13)))
        ).statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp))
                .background(Cyan.copy(alpha = .12f)).border(1.dp, Cyan.copy(alpha = .5f), RoundedCornerShape(13.dp)),
                contentAlignment = Alignment.Center) {
                Text("⌁", color = Cyan, fontSize = 29.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text("WIFI RADAR", color = White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                Text("PRO  •  NETWORK DISCOVERY", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
            }
            Box(Modifier.clip(CircleShape).background(Green.copy(alpha = .12f)).padding(horizontal = 10.dp, vertical = 6.dp)) {
                Text("ANDROID", color = Green, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }

        Row(Modifier.fillMaxWidth().padding(top = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("RADAR DE REDES", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("ANÁLISE DO AMBIENTE WI-FI", color = Cyan, fontSize = 10.sp, letterSpacing = 1.4.sp)
            }
            Text("● LIVE", color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }

        Box(Modifier.fillMaxWidth().weight(1f).padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            RadarCanvas(networks, sweep, pulse, scanning)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (scanning) "SCANNING" else "RADAR READY",
                    color = if (scanning) Green else Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("${networks.size}", color = White, fontSize = 42.sp, fontWeight = FontWeight.ExtraLight)
                Text("REDES DETECTADAS", color = Muted, fontSize = 9.sp, letterSpacing = 1.2.sp)
            }
        }

        Button(
            onClick = onScan,
            modifier = Modifier.fillMaxWidth().height(58.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)
        ) {
            Text(if (scanning) "BUSCANDO REDES…" else "◉  INICIAR RADAR",
                fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.3.sp)
        }

        Text(status, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 9.dp, bottom = 8.dp))

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("REDES PRÓXIMAS", color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.weight(1f))
            Text("${networks.size} encontradas", color = Cyan, fontSize = 10.sp)
        }

        if (networks.isEmpty()) {
            Box(Modifier.fillMaxWidth().height(92.dp).padding(top = 10.dp)
                .clip(RoundedCornerShape(14.dp)).background(Panel).border(1.dp, Color(0xFF1B3851), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center) {
                Text("Inicie o radar para listar redes ao alcance", color = Muted, fontSize = 11.sp)
            }
        } else {
            LazyColumn(Modifier.weight(0.9f, fill = false).heightIn(max = 210.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(networks, key = { it.bssid }) { network -> NetworkCard(network) }
            }
        }

        Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            OutlinedButton(onClick = onSettings, modifier = Modifier.weight(1f).height(48.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Cyan.copy(alpha = .65f)),
                shape = RoundedCornerShape(13.dp)) {
                Text("⚙  CONECTAR", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            OutlinedButton(onClick = onHistory, modifier = Modifier.weight(1f).height(48.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Green.copy(alpha = .55f)),
                shape = RoundedCornerShape(13.dp)) {
                Text("◷  HISTÓRICO ($historyCount)", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text("As redes e sinais dependem das permissões e limites do Android.",
            color = Muted.copy(alpha = .75f), fontSize = 9.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 7.dp))
    }
}

@Composable
private fun RadarCanvas(networks: List<WifiNetwork>, sweep: Float, pulse: Float, scanning: Boolean) {
    Canvas(Modifier.fillMaxWidth().aspectRatio(1f).padding(5.dp)) {
        val radius = size.minDimension * .47f
        val center = Offset(size.width / 2, size.height / 2)
        for (i in 1..4) {
            drawCircle(Cyan.copy(alpha = if (i == 4) .34f else .18f), radius = radius * i / 4f,
                center = center, style = Stroke(width = 1.dp.toPx()))
        }
        drawLine(Green.copy(alpha = .17f), Offset(center.x - radius, center.y), Offset(center.x + radius, center.y), 1.dp.toPx())
        drawLine(Green.copy(alpha = .17f), Offset(center.x, center.y - radius), Offset(center.x, center.y + radius), 1.dp.toPx())

        val angle = Math.toRadians(sweep.toDouble())
        val end = Offset(center.x + (radius * cos(angle)).toFloat(), center.y + (radius * sin(angle)).toFloat())
        drawLine(Cyan.copy(alpha = .85f), center, end, 2.dp.toPx(), cap = StrokeCap.Round)
        drawCircle(Green.copy(alpha = if (scanning) .8f else .35f), radius = 5.dp.toPx() * pulse, center = center)

        networks.take(24).forEachIndexed { index, network ->
            val hash = (network.bssid.hashCode().toLong() and 0x7fffffffL)
            val a = Math.toRadians((hash % 360).toDouble())
            val distanceFactor = (1.0 - (network.signalPercent / 100.0) * .72).coerceIn(.18, .95)
            val r = radius * distanceFactor
            val point = Offset(center.x + (cos(a) * r).toFloat(), center.y + (sin(a) * r).toFloat())
            val color = if (network.isOpen) Green else Cyan
            drawCircle(color.copy(alpha = .15f), 10.dp.toPx(), point)
            drawCircle(color, if (index == 0) 5.dp.toPx() else 3.5.dp.toPx(), point)
        }
    }
}

@Composable
private fun NetworkCard(network: WifiNetwork) {
    val color = if (network.isOpen) Green else Cyan
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel)
        .border(1.dp, color.copy(alpha = .25f), RoundedCornerShape(14.dp)).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(network.ssid, color = White, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${network.security}  •  ${network.frequency} MHz", color = Muted, fontSize = 10.sp)
            }
            Text("${network.signalPercent}%", color = color, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth().height(5.dp).clip(CircleShape).background(Color(0xFF20364A))) {
            Box(Modifier.fillMaxWidth(network.signalPercent / 100f).fillMaxHeight().clip(CircleShape).background(color))
        }
        Row(Modifier.fillMaxWidth().padding(top = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(network.proximity, color = Muted, fontSize = 10.sp)
            Spacer(Modifier.weight(1f))
            Text(if (network.isOpen) "ABERTA" else "PROTEGIDA", color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}
