# WiFi Radar Pro – Android

Aplicativo Android nativo em Kotlin + Jetpack Compose.

## O que está implementado
- Varredura real por `WifiManager.startScan()` e `scanResults`.
- Lista SSID, BSSID internamente, RSSI convertido em indicador percentual, frequência e tipo provável de segurança.
- Radar circular animado com pontos representando as redes detectadas.
- Classificação visual de redes abertas e protegidas.
- Histórico local das últimas 10 verificações.
- Atalho para as configurações de Wi-Fi do Android.
- Solicitação da permissão de localização em tempo de execução.

## Limitações importantes
- O Android exige `ACCESS_FINE_LOCATION` para expor resultados de varredura em várias versões. O usuário também pode precisar ativar os serviços de localização.
- O Android limita a frequência de varreduras; chamadas podem retornar resultados em cache ou ser recusadas pelo sistema.
- SSIDs ocultos podem aparecer sem nome.
- A intensidade RSSI não permite calcular distância física confiável. O app exibe categorias aproximadas de proximidade, não metros.
- O tipo de segurança é inferido das capacidades anunciadas pelo ponto de acesso.
- Senhas Wi-Fi não são obtidas por varredura. Redes abertas são identificadas; redes protegidas só podem ser acessadas com credenciais fornecidas pelo proprietário ou pelo próprio usuário nas configurações do sistema.
- A conexão é feita pelo painel de configurações do Android; o app não contorna autenticação.

## Gerar APK
Requisitos:
- Android Studio recente
- JDK 17
- Android SDK Platform 35
- Gradle compatível com Android Gradle Plugin 8.7.3

1. Abra a pasta `WiFiRadarPro` no Android Studio.
2. Aguarde o Gradle sincronizar e baixar as dependências.
3. Conecte um aparelho Android ou inicie um emulador com Wi-Fi.
4. Para instalar diretamente pelo Android Studio, use **Run**.
5. Para gerar APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de debug costuma ficar em `app/build/outputs/apk/debug/app-debug.apk`.

## Instalação em aparelho
Ative Wi-Fi e conceda a permissão de localização quando solicitada. Em alguns aparelhos, ative também o serviço de localização do Android para que o sistema entregue os resultados de varredura.

## Versão
1.0.0 – pacote inicial.
